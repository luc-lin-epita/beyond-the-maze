from client.menu import MainMenu

menu = MainMenu()
menu.run()