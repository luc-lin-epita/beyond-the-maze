from direct.showbase.ShowBase import ShowBase
from direct.gui.DirectGui import DirectButton, DirectLabel, DirectFrame
from panda3d.core import TransparencyAttrib
import threading
import time


class MainMenu(ShowBase):
    def __init__(self):
        super().__init__()
        self.setup_menu()

    def setup_menu(self):
        self.menu_frame = DirectFrame(
            frameColor=(0.05, 0.05, 0.05, 1),
            frameSize=(-1, 1, -1, 1)
        )

        DirectLabel(
            text="Beyond the Maze",
            scale=0.13,
            pos=(0, 0, 0.45),
            text_fg=(1, 0.85, 0.2, 1),
            frameColor=(0, 0, 0, 0),
            parent=self.menu_frame
        )

        btn_kw = dict(
            scale=0.09,
            text_fg=(1, 1, 1, 1),
            frameColor=(0.2, 0.2, 0.2, 0.9),
            frameSize=(-3.5, 3.5, -0.65, 1.0),
            relief=1,
            parent=self.menu_frame
        )

        DirectButton(
            text="Rejoindre une partie",
            pos=(0, 0, 0.1),
            command=self.join_game,
            **btn_kw
        )

        DirectButton(
            text="Héberger et jouer",
            pos=(0, 0, -0.1),
            command=self.host_game,
            text_fg=(0.4, 1, 0.4, 1),
            frameColor=(0.1, 0.25, 0.1, 0.9),
            frameSize=(-3.5, 3.5, -0.65, 1.0),
            scale=0.09,
            relief=1,
            parent=self.menu_frame
        )

        DirectButton(
            text="Quitter",
            pos=(0, 0, -0.35),
            command=self.userExit,
            text_fg=(1, 0.3, 0.3, 1),
            frameColor=(0.2, 0.1, 0.1, 0.9),
            frameSize=(-3.5, 3.5, -0.65, 1.0),
            scale=0.09,
            relief=1,
            parent=self.menu_frame
        )

        self.status_label = DirectLabel(
            text="",
            scale=0.06,
            pos=(0, 0, -0.6),
            text_fg=(0.7, 0.7, 0.7, 1),
            frameColor=(0, 0, 0, 0),
            parent=self.menu_frame
        )

    # --------------------------------------------------

    def set_status(self, msg):
        self.taskMgr.doMethodLater(
            0, lambda t: self._do_set_status(msg, t), "set_status"
        )

    def _do_set_status(self, msg, task):
        self.status_label["text"] = msg
        return task.done

    # --------------------------------------------------

    def join_game(self):
        """Cherche un serveur sur le LAN et s'y connecte."""
        self.set_status("Recherche d'un serveur sur le LAN...")
        threading.Thread(target=self._search_and_connect, daemon=True).start()

    def _search_and_connect(self):
        from shared.discovery import find_server
        result = find_server(timeout=8.0)
        if result:
            ip, port = result
            self.set_status(f"Serveur trouvé : {ip} — connexion...")
            time.sleep(0.3)
            self.taskMgr.doMethodLater(
                0, lambda t: self._launch(ip, port, t), "launch"
            )
        else:
            self.set_status("Aucun serveur trouvé. Lance d'abord un hôte.")

    # --------------------------------------------------

    def host_game(self):
        """
        Lance le serveur dans un thread background du même processus.
        Un seul terminal suffit.
        """
        self.set_status("Lancement du serveur...")

        def run_server():
            from server.server import main as server_main
            server_main()

        threading.Thread(target=run_server, daemon=True).start()

        # Laisse le serveur démarrer puis se connecte en local
        def wait_and_connect():
            time.sleep(1.5)
            self.taskMgr.doMethodLater(
                0, lambda t: self._launch("127.0.0.1", 5000, t), "launch_local"
            )

        threading.Thread(target=wait_and_connect, daemon=True).start()

    # --------------------------------------------------

    def _launch(self, ip, port, task):
        """Détruit le menu et démarre le client dans ce même ShowBase."""
        self.menu_frame.destroy()
        from client.client import start_client
        start_client(ip, port)
        return task.done