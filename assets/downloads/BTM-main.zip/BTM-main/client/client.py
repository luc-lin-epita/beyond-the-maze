from panda3d.core import (
    Vec3, TextureStage, GeomNode, Geom, GeomTriangles,
    GeomVertexData, GeomVertexFormat, GeomVertexWriter,
    WindowProperties
)
from direct.task import Task
from direct.showbase.ShowBaseGlobal import base

import socket
import threading
import json
import time
import math

from shared.discovery import find_server

GAME_PORT = 5000


# ======================================================
# UTILITAIRE RÉSEAU
# ======================================================

def recv_all(sock, size):
    data = b""
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            raise ConnectionError("Connexion fermée par le serveur.")
        data += chunk
    return data


# ======================================================
# ÉCRAN DE LOBBY
# ======================================================

def show_lobby():
    from direct.gui.DirectGui import DirectFrame, DirectLabel, DirectButton
    from direct.gui.OnscreenText import OnscreenText
    from panda3d.core import TransparencyAttrib

    base.lobby_frame = DirectFrame(
        frameColor=(0.05, 0.05, 0.05, 1),
        frameSize=(-2, 2, -2, 2),
        pos=(0, 0, 0),
    )

    base.lobby_title = DirectLabel(
        parent=base.lobby_frame,
        text="LABYRINTHE",
        scale=0.18,
        pos=(0, 0, 0.4),
        text_fg=(1, 0.85, 0.2, 1),
        frameColor=(0, 0, 0, 0),
    )

    base.lobby_status = DirectLabel(
        parent=base.lobby_frame,
        text="Recherche d'un serveur sur le LAN...",
        scale=0.07,
        pos=(0, 0, 0.1),
        text_fg=(0.8, 0.8, 0.8, 1),
        frameColor=(0, 0, 0, 0),
    )

    base.lobby_btn = DirectButton(
        parent=base.lobby_frame,
        text="Héberger moi-même",
        scale=0.08,
        pos=(0, 0, -0.15),
        command=host_and_join,
        text_fg=(1, 1, 1, 1),
        frameColor=(0.2, 0.5, 0.2, 0.9),
        frameSize=(-4, 4, -0.7, 1.1),
        relief=1,
    )

    DirectButton(
        parent=base.lobby_frame,
        text="Quitter",
        scale=0.07,
        pos=(0, 0, -0.35),
        command=base.userExit,
        text_fg=(1, 0.3, 0.3, 1),
        frameColor=(0.2, 0.2, 0.2, 0.9),
        frameSize=(-4, 4, -0.7, 1.1),
        relief=1,
    )

    threading.Thread(target=_search_server_thread, daemon=True).start()


def _search_server_thread():
    result = find_server(timeout=8.0)

    if result:
        ip, port = result
        base.taskMgr.doMethodLater(
            0, lambda t: _connect_and_start(ip, port), "connect"
        )
    else:
        base.taskMgr.doMethodLater(
            0, lambda t: _update_lobby_status("Aucun serveur trouvé. Hébergez ou réessayez."), "status"
        )


def _update_lobby_status(msg):
    if hasattr(base, "lobby_status"):
        base.lobby_status["text"] = msg
    return Task.done


def host_and_join():
    """Lance le serveur puis se connecte en local."""
    import subprocess, sys, os
    subprocess.Popen(
        [sys.executable, "server.py"],
        cwd=os.getcwd(),
        creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0,
    )
    _update_lobby_status("Serveur lancé, connexion en cours...")
    # Attend que le serveur soit prêt (1.5s suffisent)
    threading.Thread(
        target=lambda: [time.sleep(1.5), base.taskMgr.doMethodLater(
            0, lambda t: _connect_and_start("127.0.0.1", GAME_PORT), "connect_local"
        )],
        daemon=True
    ).start()


def _connect_and_start(ip, port):
    if hasattr(base, "lobby_frame"):
        base.lobby_frame.destroy()
    start_client(ip, port)
    return Task.done


# ======================================================
# START
# ======================================================

def start_client(server_ip, server_port=GAME_PORT):
    print(f"Connexion à {server_ip}:{server_port}...")

    base.player_id = None
    base.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    base.sock.connect((server_ip, server_port))

    base.state   = None
    base.running = True
    base.paused  = False

    # ===== INPUTS =====
    base.keys = {
        "up": False, "down": False, "left": False,
        "right": False, "sprint": False, "jump": False,
    }

    mapping = {"z": "up", "s": "down", "q": "left", "d": "right"}
    for panda_key, name in mapping.items():
        base.accept(panda_key, set_key, [name, True])
        base.accept(panda_key + "-up", set_key, [name, False])

    base.accept("shift",    set_key, ["sprint", True])
    base.accept("shift-up", set_key, ["sprint", False])
    base.accept("space",    set_key, ["jump", True])
    base.accept("space-up", set_key, ["jump", False])
    base.accept("escape",   toggle_pause)

    # ===== CAMÉRA FPS =====
    base.disableMouse()
    base.win.movePointer(0, base.win.getXSize() // 2, base.win.getYSize() // 2)
    base.heading = 0
    base.pitch   = 0
    base.mouse_sensitivity = 0.15
    base.camLens.setNear(0.1)

    wp = WindowProperties()
    wp.setCursorHidden(True)
    base.win.requestProperties(wp)

    # ===== UI =====
    base.hp = 100
    from direct.gui.OnscreenText import OnscreenText
    base.hp_text = OnscreenText(
        text="HP: 100", pos=(-1.3, 0.9), scale=0.07, mayChange=True
    )

    base.players_np  = {}
    base.monster_np  = None

    build_pause_menu()

    threading.Thread(target=network_send_loop, daemon=True).start()
    threading.Thread(target=network_recv_loop, daemon=True).start()
    base.taskMgr.add(update, "update")


# ======================================================
# MENU PAUSE
# ======================================================

def build_pause_menu():
    from direct.gui.DirectGui import DirectFrame, DirectButton, DirectLabel
    from panda3d.core import TransparencyAttrib

    base.pause_menu = DirectFrame(
        frameColor=(0, 0, 0, 0.65),
        frameSize=(-0.55, 0.55, -0.5, 0.5),
        pos=(0, 0, 0),
    )
    base.pause_menu.setTransparency(TransparencyAttrib.MAlpha)

    DirectLabel(
        parent=base.pause_menu, text="PAUSE", scale=0.13, pos=(0, 0, 0.35),
        text_fg=(1, 1, 1, 1), frameColor=(0, 0, 0, 0),
    )

    btn = dict(scale=0.08, text_fg=(1,1,1,1),
               frameColor=(0.25,0.25,0.25,0.9), frameSize=(-3,3,-0.6,1.0), relief=1)

    DirectButton(parent=base.pause_menu, text="Reprendre",   pos=(0,0, 0.12), command=toggle_pause,      **btn)
    DirectButton(parent=base.pause_menu, text="Plein écran", pos=(0,0,-0.05), command=toggle_fullscreen, **btn)
    DirectButton(parent=base.pause_menu, text="Quitter",     pos=(0,0,-0.22), command=quit_game,
                 text_fg=(1,0.3,0.3,1), frameColor=(0.25,0.25,0.25,0.9),
                 frameSize=(-3,3,-0.6,1.0), scale=0.08, relief=1)

    base.pause_menu.hide()


def toggle_pause():
    base.paused = not base.paused
    wp = WindowProperties()
    if base.paused:
        base.pause_menu.show()
        wp.setCursorHidden(False)
    else:
        base.pause_menu.hide()
        wp.setCursorHidden(True)
        base.win.movePointer(0, base.win.getXSize() // 2, base.win.getYSize() // 2)
    base.win.requestProperties(wp)


def toggle_fullscreen():
    props = base.win.getProperties()
    wp    = WindowProperties()
    is_full = props.getFullscreen()
    wp.setFullscreen(not is_full)
    wp.setSize(1920, 1080) if not is_full else wp.setSize(1280, 720)
    base.win.requestProperties(wp)


def quit_game():
    base.running = False
    base.userExit()


# ======================================================
# RÉSEAU
# ======================================================

def network_send_loop():
    while base.running:
        try:
            msg = json.dumps({
                "type":    "input",
                "keys":    base.keys,
                "heading": base.heading,
            }).encode()
            base.sock.sendall(len(msg).to_bytes(4, "big") + msg)
        except Exception as e:
            print("Erreur envoi :", e)
            base.running = False
            break
        time.sleep(1 / 60)

def network_recv_loop():
    while base.running:
        try:
            size_data = recv_all(base.sock, 4)
            size      = int.from_bytes(size_data, "big")
            data      = recv_all(base.sock, size)
            state     = json.loads(data.decode())
 
            if state.get("type") == "notification":
                msg = state.get("message", "")
                base.taskMgr.doMethodLater(
                    0, lambda t, m=msg: _show_notification(m, t), "notif"
                )
                continue
 
            base.state = state
 
            if base.player_id is None:
                if "your_id" in state:
                    base.player_id = str(state["your_id"])
                    print("Je suis le joueur", base.player_id)
                elif state.get("state", {}).get("players"):
                    base.player_id = str(list(state["state"]["players"].keys())[0])
                    print("Je suis le joueur (fallback)", base.player_id)
 
        except Exception as e:
            print("Erreur réception :", e)
            base.running = False


# ======================================================
# NOTIFICATIONS
# ======================================================

def _show_notification(msg, task):
    from direct.gui.OnscreenText import OnscreenText

    notif = OnscreenText(
        text=msg,
        pos=(0, 0.55),
        scale=0.07,
        fg=(0.3, 1, 0.3, 1),
        shadow=(0, 0, 0, 0.9),
        mayChange=False,
    )
    # Supprime la notification après 3 secondes
    base.taskMgr.doMethodLater(3, lambda t: [notif.destroy(), task.done][1], "remove_notif")
    return task.done


# ======================================================
# CAMÉRA SOURIS
# ======================================================

def update_camera_mouse():
    if base.paused or not base.mouseWatcherNode.hasMouse():
        return

    cx = base.win.getXSize() // 2
    cy = base.win.getYSize() // 2
    md = base.win.getPointer(0)
    dx = md.getX() - cx
    dy = md.getY() - cy

    base.heading -= dx * base.mouse_sensitivity
    base.pitch   -= dy * base.mouse_sensitivity
    base.pitch    = max(-80, min(80, base.pitch))

    base.camera.setHpr(base.heading, base.pitch, 0)
    base.win.movePointer(0, cx, cy)


# ======================================================
# UPDATE
# ======================================================

def update(task):
    if base.state is None or "state" not in base.state:
        return Task.cont

    state = base.state["state"]
    update_camera_mouse()

    if not hasattr(base, "maze_built"):
        build_maze(state["maze"])
        base.maze_built = True

    # Joueurs
    current_pids = set(str(pid) for pid in state["players"].keys())
    for pid in list(base.players_np.keys()):
        if pid not in current_pids:
            base.players_np[pid].removeNode()
            del base.players_np[pid]

    for pid, pdata in state["players"].items():
        pid = str(pid)
        pos = pdata["pos"]

        if pid == str(base.player_id):
            base.hp = pdata.get("hp", base.hp)
            cam_z   = (pos[2] if len(pos) > 2 else 0) + 1.7
            base.camera.setPos(pos[0], pos[1], cam_z)
            continue

        if pid not in base.players_np:
            np = base.loader.loadModel("models/box")
            np.setColor(0, 0, 1, 1)
            np.setScale(0.4, 0.4, 0.9)
            np.reparentTo(base.render)
            base.players_np[pid] = np

        base.players_np[pid].setPos(pos[0], pos[1], 0)

    # Monstre
    if "monster" in state:
        if base.monster_np is None:
            base.monster_np = base.loader.loadModel("models/box")
            base.monster_np.setColor(1, 0, 0, 1)
            base.monster_np.setScale(0.6, 0.6, 1.2)
            base.monster_np.reparentTo(base.render)
        mx, my = state["monster"]
        base.monster_np.setPos(mx, my, 0)

    base.hp_text.setText(f"HP: {base.hp}")
    return Task.cont


# ======================================================
# LABYRINTHE — génération par faces exposées
# ======================================================

def make_quad(verts, uvs):
    fmt   = GeomVertexFormat.getV3t2()
    vdata = GeomVertexData("quad", fmt, Geom.UHStatic)
    vdata.setNumRows(4)
    v_wr  = GeomVertexWriter(vdata, "vertex")
    uv_wr = GeomVertexWriter(vdata, "texcoord")

    for (x, y, z), (u, v) in zip(verts, uvs):
        v_wr.addData3(x, y, z)
        uv_wr.addData2(u, v)

    tris = GeomTriangles(Geom.UHStatic)
    tris.addVertices(0, 1, 2)
    tris.addVertices(0, 2, 3)

    geom = Geom(vdata)
    geom.addPrimitive(tris)
    node = GeomNode("quad")
    node.addGeom(geom)
    return node


def build_maze(maze):
    print("Construction du labyrinthe...")

    cell   = 4.0
    wall_h = 4.0
    rows   = len(maze)
    cols   = len(maze[0])

    wall_tex  = base.loader.loadTexture("assets/textures/wall.png")
    floor_tex = base.loader.loadTexture("assets/textures/floor.png")
    ceil_tex  = base.loader.loadTexture("assets/textures/ceiling.png")

    for tex in (wall_tex, floor_tex, ceil_tex):
        tex.setWrapU(tex.WMRepeat)
        tex.setWrapV(tex.WMRepeat)

    ts = TextureStage.getDefault()

    def is_wall(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return True
        return maze[r][c] != " "

    root = base.render

    for r in range(rows):
        for c in range(cols):
            x0, x1 = c * cell, c * cell + cell
            y0, y1 = r * cell, r * cell + cell

            if is_wall(r, c):
                if not is_wall(r + 1, c):
                    np = root.attachNewNode(make_quad(
                        [(x1,y1,0),(x0,y1,0),(x0,y1,wall_h),(x1,y1,wall_h)],
                        [(0,0),(1,0),(1,1),(0,1)]))
                    np.setTexture(ts, wall_tex)

                if not is_wall(r - 1, c):
                    np = root.attachNewNode(make_quad(
                        [(x0,y0,0),(x1,y0,0),(x1,y0,wall_h),(x0,y0,wall_h)],
                        [(0,0),(1,0),(1,1),(0,1)]))
                    np.setTexture(ts, wall_tex)

                if not is_wall(r, c + 1):
                    np = root.attachNewNode(make_quad(
                        [(x1,y0,0),(x1,y1,0),(x1,y1,wall_h),(x1,y0,wall_h)],
                        [(0,0),(1,0),(1,1),(0,1)]))
                    np.setTexture(ts, wall_tex)

                if not is_wall(r, c - 1):
                    np = root.attachNewNode(make_quad(
                        [(x0,y1,0),(x0,y0,0),(x0,y0,wall_h),(x0,y1,wall_h)],
                        [(0,0),(1,0),(1,1),(0,1)]))
                    np.setTexture(ts, wall_tex)
            else:
                np = root.attachNewNode(make_quad(
                    [(x0,y0,0),(x1,y0,0),(x1,y1,0),(x0,y1,0)],
                    [(0,0),(1,0),(1,1),(0,1)]))
                np.setTexture(ts, floor_tex)

                np = root.attachNewNode(make_quad(
                    [(x0,y1,wall_h),(x1,y1,wall_h),(x1,y0,wall_h),(x0,y0,wall_h)],
                    [(0,0),(1,0),(1,1),(0,1)]))
                np.setTexture(ts, ceil_tex)

    print("Labyrinthe construit.")


# ======================================================
# INPUTS
# ======================================================

def set_key(key, value):
    base.keys[key] = value