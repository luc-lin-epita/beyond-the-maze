import socket
import threading
import time

from server.game_logic import GameState
from shared.protocol import send, recv
from shared.discovery import ServerAnnouncer   # <<< nouveau

# =====================
# CONFIGURATION
# =====================

HOST        = "0.0.0.0"
PORT        = 5000
MAX_PLAYERS = 4
TICK_RATE   = 60

# =====================
# ÉTAT DU JEU
# =====================

game               = GameState()
clients            = {}
clients_lock       = threading.Lock()
player_inputs      = {}
player_inputs_lock = threading.Lock()

# =====================
# THREAD RÉSEAU — reçoit les inputs d'un client
# =====================

def handle_client(conn, addr, pid):
    print(f"[SERVER] Joueur {pid} connecté depuis {addr}")
    game.add_player(pid)


    # Notification quand un joueur rejoint
    with clients_lock:
        clients_snapshot = dict(clients)
    for other_pid, other_conn in clients_snapshot.items():
        try:
            send(other_conn, {
                "type":    "notification",
                "message": f"Joueur {pid} a rejoint la partie !",
                "pid":     pid,
            })
        except Exception:
            pass
    with player_inputs_lock:
        player_inputs[pid] = {"keys": {}, "heading": 0.0}

    try:
        while True:
            msg = recv(conn)
            if msg is None:
                break

            if msg.get("type") == "input":
                with player_inputs_lock:
                    player_inputs[pid] = {
                        "keys":    msg.get("keys", {}),
                        "heading": msg.get("heading", 0.0),
                    }

    except Exception as e:
        print(f"[SERVER] Erreur joueur {pid} :", e)

    finally:
        print(f"[SERVER] Joueur {pid} déconnecté")
        game.remove_player(pid)
        with player_inputs_lock:
            player_inputs.pop(pid, None)
        with clients_lock:
            clients.pop(pid, None)
        conn.close()


# =====================
# THREAD ENVOI
# =====================

def send_state(pid, conn, state):
    try:
        send(conn, {
            "type":    "state",
            "your_id": pid,
            "state":   state,
        })
    except Exception:
        pass


# =====================
# BOUCLE DE JEU
# =====================

def game_loop():
    tick_duration = 1.0 / TICK_RATE
    last_time = time.time()

    while True:
        now = time.time()
        dt  = now - last_time
        last_time = now

        with player_inputs_lock:
            inputs_snapshot = dict(player_inputs)

        for pid, inp in inputs_snapshot.items():
            game.update_player(pid, inp["keys"], dt, inp["heading"])

        game.update_monster(dt)

        state = game.get_state()
        with clients_lock:
            clients_snapshot = dict(clients)

        for pid, conn in clients_snapshot.items():
            send_state(pid, conn, state)

        elapsed    = time.time() - now
        sleep_time = tick_duration - elapsed
        if sleep_time > 0:
            time.sleep(sleep_time)


# =====================
# BOUCLE SERVEUR
# =====================

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen()

    print("[SERVER] Serveur lancé")
    print(f"[SERVER] En attente de joueurs sur le port {PORT}...")

    # Lance l'annonce broadcast pour que les clients trouvent ce serveur
    announcer = ServerAnnouncer(game_port=PORT)
    announcer.start()

    # Lance la game loop dans un thread dédié
    threading.Thread(target=game_loop, daemon=True).start()

    next_pid = 1

    while True:
        conn, addr = server_socket.accept()

        with clients_lock:
            if next_pid > MAX_PLAYERS:
                print("[SERVER] Serveur plein")
                conn.close()
                continue

            pid = next_pid
            clients[pid] = conn
            next_pid += 1

        threading.Thread(
            target=handle_client,
            args=(conn, addr, pid),
            daemon=True
        ).start()


if __name__ == "__main__":
    main()