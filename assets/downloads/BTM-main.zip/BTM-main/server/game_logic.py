import random
import math

# ======================================================
# CONSTANTES PHYSIQUE
# ======================================================

SPRINT_MULT    = 1.8    # multiplicateur de vitesse sprint
JUMP_FORCE     = 8.0    # vitesse verticale initiale au saut
GRAVITY        = -20.0  # accélération gravitationnelle (unités/s²)
FLOOR_Z        = 0.0    # altitude du sol
MONSTER_DMG    = 15.0   # dégâts/seconde au contact du monstre
MONSTER_RADIUS = 2.0    # rayon de contact monstre → joueur


class GameState:
    def __init__(self):
        # ===== PARAMÈTRES GLOBAUX =====
        self.cell_size = 4.0
        self.width  = 15   # DOIT ÊTRE IMPAIR
        self.height = 11   # DOIT ÊTRE IMPAIR

        # ===== LABYRINTHE =====
        self.maze = self.generate_maze(self.width, self.height)

        # ===== JOUEURS =====
        self.players = {}
        self.player_speed = 6.0

        # ===== MONSTRE =====
        self.monster_speed = 4.0
        self.monster_pos   = self.get_random_free_cell()

        # ===== SORTIE =====
        self.exit_pos = (
            (self.width  - 2) * self.cell_size,
            (self.height - 2) * self.cell_size
        )

    # ======================================================
    # LABYRINTHE ALÉATOIRE (DFS / BACKTRACKING)
    # ======================================================

    def generate_maze(self, width, height):
        maze = [["#"] * width for _ in range(height)]

        def carve(x, y):
            directions = [(2, 0), (-2, 0), (0, 2), (0, -2)]
            random.shuffle(directions)
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                if 1 <= nx < width - 1 and 1 <= ny < height - 1:
                    if maze[ny][nx] == "#":
                        maze[ny][nx] = " "
                        maze[y + dy // 2][x + dx // 2] = " "
                        carve(nx, ny)

        maze[1][1] = " "
        carve(1, 1)

        return ["".join(row) for row in maze]

    # ======================================================
    # JOUEURS
    # ======================================================

    def add_player(self, pid):
        pawn_x = 1 * self.cell_size  # = 4.0
        pawn_y = 1 * self.cell_size  # = 4.0
        self.players[pid] = {
            "pos":       [pawn_x, pawn_y, FLOOR_Z],
            "vz":        0.0,
            "on_ground": True,
        "heading":   0.0,
        "hp":        100.0,
        "alive":     True,
    }

    def remove_player(self, pid):
        if pid in self.players:
            del self.players[pid]

    def update_player(self, pid, inputs: dict, dt: float, heading: float = 0.0):
        if pid not in self.players:
            return

        p = self.players[pid]
        if not p["alive"]:
            return

        p["heading"] = heading

        # --- Vitesse (sprint) ---
        speed = self.player_speed * (SPRINT_MULT if inputs.get("sprint") else 1.0) * dt

        # --- Direction orientée selon le heading caméra ---
        rad = math.radians(heading)
        fwd = (-math.sin(rad),  math.cos(rad))   # vecteur "avant"
        rgt = ( math.cos(rad),  math.sin(rad))   # vecteur "droite"

        move_x = move_y = 0.0

        if inputs.get("up"):
            move_x += fwd[0]; move_y += fwd[1]
        if inputs.get("down"):
            move_x -= fwd[0]; move_y -= fwd[1]
        if inputs.get("right"):
            move_x += rgt[0]; move_y += rgt[1]
        if inputs.get("left"):
            move_x -= rgt[0]; move_y -= rgt[1]

        # Normalisation pour éviter la vitesse diagonale augmentée
        length = math.hypot(move_x, move_y)
        if length > 0:
            move_x = move_x / length * speed
            move_y = move_y / length * speed

        x, y, z = p["pos"]

        # --- Collision glissante (axes séparés) ---
        if self.can_move_to(x + move_x, y):
            x += move_x
        if self.can_move_to(x, y + move_y):
            y += move_y

        # --- Saut ---
        if inputs.get("jump") and p["on_ground"]:
            p["vz"]        = JUMP_FORCE
            p["on_ground"] = False

        # --- Physique verticale ---
        if not p["on_ground"]:
            p["vz"] += GRAVITY * dt
            z       += p["vz"] * dt
            if z <= FLOOR_Z:
                z              = FLOOR_Z
                p["vz"]        = 0.0
                p["on_ground"] = True

        p["pos"] = [x, y, z]

        # --- Dégâts monstre ---
        if self.distance((x, y), self.monster_pos) < MONSTER_RADIUS:
            p["hp"] = max(0.0, p["hp"] - MONSTER_DMG * dt)
            if p["hp"] <= 0:
                p["alive"] = False

    # ======================================================
    # MONSTRE (poursuite simple)
    # ======================================================

    def update_monster(self, dt):
        if not self.players:
            return

        living = [p for p in self.players.values() if p["alive"]]
        if not living:
            return

        target = min(living, key=lambda p: self.distance(p["pos"][:2], self.monster_pos))
        tx, ty = target["pos"][:2]
        mx, my = self.monster_pos

        dx, dy = tx - mx, ty - my
        dist = math.hypot(dx, dy)
        if dist == 0:
            return

        step = self.monster_speed * dt
        nx = mx + (dx / dist) * step
        ny = my + (dy / dist) * step

        if self.can_move_to(nx, my):
            mx = nx
        if self.can_move_to(mx, ny):
            my = ny

        self.monster_pos = (mx, my)

    # ======================================================
    # COLLISIONS LABYRINTHE
    # ======================================================

    def can_move_to(self, x, y):
        cx = int(x // self.cell_size)
        cy = int(y // self.cell_size)

        if cy < 0 or cy >= self.height or cx < 0 or cx >= self.width:
            return False

        return self.maze[cy][cx] == " "

    # ======================================================
    # OUTILS
    # ======================================================

    def get_random_free_cell(self):
        while True:
            x = random.randrange(1, self.width  - 1)
            y = random.randrange(1, self.height - 1)
            if self.maze[y][x] == " ":
                return (x * self.cell_size, y * self.cell_size)

    def distance(self, a, b):
        return math.hypot(a[0] - b[0], a[1] - b[1])

    # ======================================================
    # ÉTAT GLOBAL (ENVOYÉ AU CLIENT)
    # ======================================================

    def get_state(self):
        players_data = {}
        for pid, p in self.players.items():
            players_data[pid] = {
                "pos":   p["pos"],           # [x, y, z]
                "hp":    round(p["hp"], 1),
                "alive": p["alive"],
            }

        return {
            "maze":    self.maze,
            "players": players_data,
            "monster": list(self.monster_pos),
            "exit":    list(self.exit_pos),
        }