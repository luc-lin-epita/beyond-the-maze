# shared/discovery.py
#
# Découverte automatique du serveur en LAN via UDP broadcast.
# Le serveur envoie régulièrement une annonce sur le réseau.
# Le client écoute et récupère l'IP du serveur automatiquement.

import socket
import threading
import time

DISCOVERY_PORT    = 5001          # port UDP dédié à la découverte
BROADCAST_ADDR    = "255.255.255.255"
ANNOUNCE_MSG      = b"LABYRINTHE_SERVER"
ANNOUNCE_INTERVAL = 2.0           # secondes entre chaque annonce


# ======================================================
# CÔTÉ SERVEUR — annonce sa présence en broadcast
# ======================================================

class ServerAnnouncer:
    """Lance un thread qui diffuse l'IP du serveur toutes les 2 secondes."""

    def __init__(self, game_port: int = 5000):
        self.game_port = game_port
        self._running  = False
        self._thread   = None

    def start(self):
        self._running = True
        self._thread  = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        print(f"[DISCOVERY] Annonce broadcast lancée sur le port UDP {DISCOVERY_PORT}")

    def stop(self):
        self._running = False

    def _loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        # Message = "LABYRINTHE_SERVER:<port_tcp>"
        msg = f"LABYRINTHE_SERVER:{self.game_port}".encode()

        while self._running:
            try:
                sock.sendto(msg, (BROADCAST_ADDR, DISCOVERY_PORT))
            except Exception as e:
                print(f"[DISCOVERY] Erreur broadcast : {e}")
            time.sleep(ANNOUNCE_INTERVAL)

        sock.close()


# ======================================================
# CÔTÉ CLIENT — écoute le broadcast et retourne l'IP
# ======================================================

def find_server(timeout: float = 10.0):
    """
    Écoute le réseau LAN jusqu'à trouver un serveur ou expirer.

    Retourne (ip, port) si trouvé, sinon None.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.settimeout(timeout)

    try:
        sock.bind(("", DISCOVERY_PORT))
        print(f"[DISCOVERY] Recherche d'un serveur sur le LAN... (timeout {timeout}s)")

        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                data, (ip, _) = sock.recvfrom(64)
                msg = data.decode()
                if msg.startswith("LABYRINTHE_SERVER:"):
                    port = int(msg.split(":")[1])
                    print(f"[DISCOVERY] Serveur trouvé : {ip}:{port}")
                    return ip, port
            except socket.timeout:
                break
            except Exception:
                continue

    finally:
        sock.close()

    print("[DISCOVERY] Aucun serveur trouvé sur le LAN.")
    return None