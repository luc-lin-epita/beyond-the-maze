import json


def send(sock, data):
    msg = json.dumps(data).encode()
    sock.sendall(len(msg).to_bytes(4, "big") + msg)


def recv(sock):
    # Lecture robuste : on s'assure de recevoir EXACTEMENT les bons octets
    size_data = _recv_all(sock, 4)
    if not size_data:
        return None
    size = int.from_bytes(size_data, "big")
    data = _recv_all(sock, size)
    if not data:
        return None
    return json.loads(data.decode())


def _recv_all(sock, size):
    """Lit exactement `size` octets — gère la fragmentation TCP."""
    data = b""
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            return None
        data += chunk
    return data